from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from os import path
from flask_login import LoginManager
db = SQLAlchemy()


# sqlite:////tmp/test.db

# mysql://username:password@server/db
# root:2031@localhost/airlinemanagementsystem

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'AMS'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:2031@localhost/airlinemanagementsystem'
    # app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlclient://root:2031@localhost/airlinemanagementsystem' OR THIS !!!!
    # app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://'
    # app.config['MYSQL_HOST'] = 'localhost'
    # app.config['MYSQL_USER'] = 'root'
    # app.config['MYSQL_PASSWORD'] = '2031'
    # app.config['MYSQL_DB'] = 'flask'
    db.init_app(app)

    from .views import views
    from .auth import auth
    from .airplanes import airplanes


    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(airplanes, url_prefix='/')

    from .models import User
    
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))

    return app