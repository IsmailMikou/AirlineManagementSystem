from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from . import db
from flask import redirect, url_for

views = Blueprint('views',__name__)

@views.route('/')
@login_required
def home():
    return render_template("home.html", user=current_user)

@views.route('/airplanes',methods=['GET','POST'])
@login_required
def airplane():
    if request.method == 'GET':
        return render_template("aircraft.html", user=current_user)
    return render_template("login.html", user=current_user)

@views.route('/airports',methods=['GET','POST'])
@login_required
def airport():
    if request.method == 'GET':
        return render_template("airports.html", user=current_user)
    return render_template("login.html", user=current_user)

@views.route('/routes',methods=['GET','POST'])
@login_required
def route():
    if request.method == 'GET':
        return render_template("routes.html", user=current_user)
    return render_template("login.html", user=current_user)

@views.route('/flights',methods=['GET','POST'])
@login_required
def flight():
    if request.method == 'GET':
        return render_template("flights.html", user=current_user)
    return render_template("login.html", user=current_user)

@views.route('/bookings',methods=['GET','POST'])
@login_required
def booking():
    if request.method == 'GET':
        return render_template("bookings.html", user=current_user)
    return render_template("login.html", user=current_user)

@views.route('/payements',methods=['GET','POST'])
@login_required
def payement():
    if request.method == 'GET':
        return render_template("payements.html", user=current_user)
    return render_template("login.html", user=current_user)